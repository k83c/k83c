# TTNC [PATCHED]

TikTok 4L and 4C checker that doesn't count banned usernames as available. Once a username is available, it will send it to your Discord Webhook. Auto proxy scraper is included!

## Replit Version 
Here is a replit version for this: https://replit.com/@cliphd/ttnc It can used on any platform.

## Setting it up

* Download the latest verison of [Python](https://www.python.org/). When installing, make sure to click "Add Python to PATH".

* After you've installed Python, run `setup.bat`.

## Preview

![TTNC_DEMO](https://user-images.githubusercontent.com/80993711/150610148-62c4db3b-68db-49ce-a615-37b5fab4b788.gif)

https://user-images.githubusercontent.com/80993711/150702314-7610a462-b6b7-4253-8c18-8f4923ce3368.mov

## License

MIT
